#!/bin/bash
while true
do
# Ketentuan 1: Menampilkan ukuran memory pada sistem dalam satuan megabytes
echo "=== Ukuran Memori ==="
free -m
sleep 3

# Ketentuan 2: Menampilkan penggunaan ruang disk pada filesystem dalam satuan gigabytes
echo -e "\n=== Penggunaan Ruang Disk ==="
df -BG
sleep 3

# Ketentuan 3: Menampilkan penggunaan ruang disk pada filesystem hanya untuk kolom Filesystem dan Use% (tanpa tmpfs)
echo -e "\n=== Penggunaan Ruang untuk Filesystem tanpa tmpfs ==="
df -h | awk '!/tmpfs/ { print $1, $5 }' | column -t
sleep 1m
done
